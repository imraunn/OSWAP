<?php
    $flag="oswap{level_6}";
?>