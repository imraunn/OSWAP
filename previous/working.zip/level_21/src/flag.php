<?php
    $flag="oswap{level_21}";
?>