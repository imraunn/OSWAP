<?php
    $flag="oswap{level_10}";
?>