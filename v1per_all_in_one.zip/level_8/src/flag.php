<?php
	$flag="oswap{e0ef97af463ccbfe4d876246c4f9d6d3}";
?>
