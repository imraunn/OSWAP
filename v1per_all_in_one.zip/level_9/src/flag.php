<?php
	$flag="oswap{be6c066675d3b22462aeb9dca7b846b1}";
?>
