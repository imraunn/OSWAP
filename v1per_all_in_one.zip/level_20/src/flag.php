<?php
	$flag="oswap{65b8a395caea802be6d130f58f960199}";
?>
