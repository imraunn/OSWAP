<?php
    $flag="oswap{level_1}";
?>