<?php
    $flag="oswap{level_7}";
?>