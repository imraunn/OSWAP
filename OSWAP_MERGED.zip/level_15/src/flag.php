<?php
	$flag="oswap{12da7ff8330f29d5508987d282f2fa8d}";
?>
