<?php
	$flag="oswap{7f61afc6c0e19a71386f372e0f28a986}";
?>
