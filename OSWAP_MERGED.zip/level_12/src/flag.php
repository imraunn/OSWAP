<?php
    $flag="oswap{level_12}";
?>