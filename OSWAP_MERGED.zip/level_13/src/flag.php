<?php
	$flag="oswap{b4151e7a528b814e7b115343bab1450d}";
?>
